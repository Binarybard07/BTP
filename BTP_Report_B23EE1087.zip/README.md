# MTP-template-IITJ
M.Tech. Report Template of IIT Jodhpur

1. Add Title of the Project Report, Name of this Supervisor, Name of the Degree, Name of the Student, Roll Number of the Student and Name of the Department in main.tex, in actual application.
2. Run pdflatex main.tex
